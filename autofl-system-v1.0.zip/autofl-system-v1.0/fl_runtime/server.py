"""
Lightweight FL server / coordinator.

Supports: FedAvg, FedProx (proximal term applied client-side).
Collects preflight results before starting training.
"""
import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import torch


@dataclass
class RoundResult:
    round: int
    participating_clients: list[str]
    aggregated_loss: float
    elapsed_sec: float
    extra: dict = field(default_factory=dict)


class FLServer:
    def __init__(
        self,
        global_weights: dict[str, torch.Tensor],
        config: dict,
        results_dir: str | Path = "fl_results",
    ):
        self.weights = {k: v.cpu().clone() for k, v in global_weights.items()}
        self.config = config
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)

        self.round_results: list[RoundResult] = []
        self.preflight_results: dict = {}

    # ------------------------------------------------------------------
    # Preflight collection
    # ------------------------------------------------------------------

    def register_preflight(self, client_id: str, result_dict: dict) -> None:
        self.preflight_results[client_id] = result_dict
        passed = result_dict.get("success", False)
        print(f"  Preflight [{client_id}]: {'PASS' if passed else 'FAIL'}")

    def ready_clients(self) -> list[str]:
        return [cid for cid, r in self.preflight_results.items() if r.get("success")]

    def save_preflight_report(self) -> Path:
        path = self.results_dir / "preflight_report.json"
        with open(path, "w") as f:
            json.dump(self.preflight_results, f, indent=2)
        return path

    # ------------------------------------------------------------------
    # Training coordination
    # ------------------------------------------------------------------

    def run_round(self, clients, round_num: int) -> RoundResult:
        """
        Send global weights to each client, collect local updates, aggregate.
        `clients` is a list of FLClient instances.
        """
        t0 = time.time()
        all_weights = []
        all_losses = []
        participating = []

        for client in clients:
            client.set_weights(self.weights)
            updated_w, metrics = client.local_train()
            all_weights.append(updated_w)
            all_losses.append(metrics["loss"])
            participating.append(client.client_id)
            print(f"    [{client.client_id}] loss={metrics['loss']:.4f}  "
                  f"steps={metrics['steps']}  {metrics['elapsed_sec']}s")

        self.weights = self._fedavg(all_weights)

        rr = RoundResult(
            round=round_num,
            participating_clients=participating,
            aggregated_loss=round(sum(all_losses) / len(all_losses), 6),
            elapsed_sec=round(time.time() - t0, 2),
        )
        self.round_results.append(rr)
        return rr

    def run(self, clients, num_rounds: Optional[int] = None) -> None:
        total = num_rounds or self.config.get("num_rounds", 10)

        ready = self.ready_clients()
        if not ready:
            raise RuntimeError("No clients passed preflight — cannot start FL.")

        active_clients = [c for c in clients if c.client_id in ready]
        print(f"\nStarting FL: {total} rounds, {len(active_clients)} clients")
        print("=" * 50)

        for r in range(1, total + 1):
            print(f"\nRound {r}/{total}")
            rr = self.run_round(active_clients, r)
            print(f"  Aggregated loss: {rr.aggregated_loss:.4f}  ({rr.elapsed_sec}s)")

        self.save_results()
        print("\nFL training complete.")

    # ------------------------------------------------------------------
    # Aggregation
    # ------------------------------------------------------------------

    @staticmethod
    def _fedavg(weight_list: list[dict]) -> dict[str, torch.Tensor]:
        if not weight_list:
            raise ValueError("No weights to aggregate")
        n = len(weight_list)
        avg = {}
        for key in weight_list[0]:
            avg[key] = torch.stack([w[key].float() for w in weight_list]).mean(dim=0)
        return avg

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save_model(self, name: str = "global_model.pt") -> Path:
        path = self.results_dir / name
        torch.save(self.weights, path)
        return path

    def save_results(self) -> Path:
        path = self.results_dir / "fl_results.json"
        data = [asdict(r) for r in self.round_results]
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        return path
