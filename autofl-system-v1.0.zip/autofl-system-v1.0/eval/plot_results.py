"""Generate publication-quality figures from benchmark.csv."""
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

RESULTS_DIR = Path(__file__).parent.parent / "results"
FIG_DIR = RESULTS_DIR / "figures"
FIG_DIR.mkdir(exist_ok=True)

METHODS = ["ast", "zero_shot", "few_shot", "structured"]
METHOD_LABELS = ["AST", "Zero-shot", "Few-shot", "Structured"]
FRAMEWORKS = ["pytorch", "tensorflow", "monai", "lightning"]
FW_LABELS = ["PyTorch", "TensorFlow", "MONAI", "Lightning"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52"]


def load(path: str | Path) -> list[dict]:
    return list(csv.DictReader(open(path)))


def _orig(rows):
    """Return only rows for original scripts (exclude pre-generated _fl_ files)."""
    return [x for x in rows if "_fl_" not in x["script_name"]]


def rate(rows, fw, method, col):
    r = [x for x in _orig(rows) if x["framework"] == fw and x["method"] == method]
    if not r:
        return 0.0
    return sum(x[col] == "True" for x in r) / len(r)


def mean_cov(rows, fw, method):
    r = [x for x in _orig(rows) if x["framework"] == fw and x["method"] == method]
    if not r:
        return 0.0
    return sum(float(x["component_coverage"]) for x in r) / len(r)


def fig1_e2e_heatmap(rows):
    """Heatmap: e2e_runnable rate — frameworks × methods."""
    data = np.array([
        [rate(rows, fw, m, "e2e_runnable") for m in METHODS]
        for fw in FRAMEWORKS
    ])
    fig, ax = plt.subplots(figsize=(7, 3.5))
    im = ax.imshow(data, vmin=0, vmax=1, cmap="RdYlGn", aspect="auto")
    ax.set_xticks(range(len(METHODS))); ax.set_xticklabels(METHOD_LABELS, fontsize=11)
    ax.set_yticks(range(len(FRAMEWORKS))); ax.set_yticklabels(FW_LABELS, fontsize=11)
    for i in range(len(FRAMEWORKS)):
        for j in range(len(METHODS)):
            ax.text(j, i, f"{data[i,j]:.0%}", ha="center", va="center",
                    fontsize=12, color="black" if data[i,j] < 0.7 else "white",
                    fontweight="bold")
    plt.colorbar(im, ax=ax, label="e2e success rate")
    ax.set_title("End-to-end FL Runnable Rate by Skill × Framework", fontsize=13, pad=10)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig1_e2e_heatmap.pdf", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig1_e2e_heatmap.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved fig1_e2e_heatmap")


def fig2_coverage_grouped(rows):
    """Grouped bar: component_coverage per method × framework."""
    x = np.arange(len(FRAMEWORKS))
    width = 0.18
    fig, ax = plt.subplots(figsize=(8, 4))
    for i, (m, label, color) in enumerate(zip(METHODS, METHOD_LABELS, COLORS)):
        vals = [mean_cov(rows, fw, m) for fw in FRAMEWORKS]
        ax.bar(x + (i - 1.5) * width, vals, width, label=label, color=color, alpha=0.85)
    ax.set_xticks(x); ax.set_xticklabels(FW_LABELS, fontsize=11)
    ax.set_ylabel("Component Coverage (mean)", fontsize=11)
    ax.set_ylim(0, 1.1)
    ax.axhline(1.0, color="gray", linestyle="--", linewidth=0.8, alpha=0.5)
    ax.legend(fontsize=10, loc="lower right")
    ax.set_title("Component Coverage by Skill × Framework", fontsize=13)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig2_coverage_grouped.pdf", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig2_coverage_grouped.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved fig2_coverage_grouped")


def fig3_stage_breakdown(rows):
    """Grouped bar: pass rate at each pipeline stage, per method × framework."""
    stage_cols = [
        ("interface_complete", "Interface\nComplete", "#4393c3"),
        ("preflight_pass",     "Preflight\nPass",     "#92c5de"),
        ("e2e_runnable",       "E2E\nRunnable",       "#1a9641"),
    ]
    fig, axes = plt.subplots(1, len(FRAMEWORKS), figsize=(13, 4), sharey=True)
    width = 0.2
    x = np.arange(len(METHODS))
    for ax, fw, fw_label in zip(axes, FRAMEWORKS, FW_LABELS):
        for i, (col, label, color) in enumerate(stage_cols):
            vals = np.array([rate(rows, fw, m, col) for m in METHODS])
            ax.bar(x + (i - 1) * width, vals, width, label=label, color=color, alpha=0.85)
        ax.set_title(fw_label, fontsize=11)
        ax.set_xticks(x)
        ax.set_xticklabels(METHOD_LABELS, rotation=30, ha="right", fontsize=9)
        ax.set_ylim(0, 1.15)
        ax.axhline(1.0, color="gray", linestyle="--", linewidth=0.7, alpha=0.4)
    axes[0].set_ylabel("Pass Rate", fontsize=11)
    handles = [mpatches.Patch(color=c, label=l.replace("\n", " ")) for _, l, c in stage_cols]
    fig.legend(handles=handles, loc="upper right", fontsize=9, bbox_to_anchor=(1.01, 1.0))
    fig.suptitle("Pipeline Stage Pass Rates by Skill × Framework", fontsize=13)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_stage_breakdown.pdf", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig3_stage_breakdown.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved fig3_stage_breakdown")


def fig4_per_script(rows):
    """Per-script success heatmap across 10 original scripts × 4 methods."""
    scripts = sorted(set(r["script_name"] for r in _orig(rows)))
    data = np.array([
        [1 if any(
            x["e2e_runnable"] == "True"
            for x in rows if x["script_name"] == s and x["method"] == m
        ) else 0
         for m in METHODS]
        for s in scripts
    ])
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(data, vmin=0, vmax=1, cmap="RdYlGn", aspect="auto")
    ax.set_xticks(range(len(METHODS))); ax.set_xticklabels(METHOD_LABELS, fontsize=10)
    ax.set_yticks(range(len(scripts)))
    ax.set_yticklabels([s.replace("_main", "").replace("_tutorial", "")
                        .replace("_from_scratch", "_scratch")
                        .replace("_segmentation_3d", "_3d") for s in scripts], fontsize=9)
    for i in range(len(scripts)):
        for j in range(len(METHODS)):
            ax.text(j, i, "✓" if data[i, j] else "✗", ha="center", va="center",
                    fontsize=12, color="white" if data[i, j] else "black")
    ax.set_title("Per-Script E2E Success", fontsize=13)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig4_per_script.pdf", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "fig4_per_script.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved fig4_per_script")


def main():
    csv_path = RESULTS_DIR / "benchmark.csv"
    if not csv_path.exists():
        print(f"benchmark.csv not found at {csv_path}")
        sys.exit(1)
    rows = load(csv_path)
    print(f"Loaded {len(rows)} rows")

    fig1_e2e_heatmap(rows)
    fig2_coverage_grouped(rows)
    fig3_stage_breakdown(rows)
    fig4_per_script(rows)

    print(f"\nAll figures saved to {FIG_DIR}")


if __name__ == "__main__":
    main()
