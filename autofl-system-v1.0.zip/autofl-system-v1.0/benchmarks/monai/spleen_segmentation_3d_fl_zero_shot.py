# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from glob import glob

import torch
from torch.utils.data import DataLoader

import monai
from monai.data import list_data_collate
from monai.transforms import (
    Compose,
    EnsureChannelFirstd,
    LoadImaged,
    RandCropByPosNegLabeld,
    RandRotate90d,
    ScaleIntensityd,
)


def build_model(config):
    device = torch.device(config.get("device", "cuda" if torch.cuda.is_available() else "cpu"))
    model = monai.networks.nets.UNet(
        spatial_dims=config.get("spatial_dims", 3),
        in_channels=config.get("in_channels", 1),
        out_channels=config.get("out_channels", 1),
        channels=config.get("channels", (16, 32, 64, 128, 256)),
        strides=config.get("strides", (2, 2, 2, 2)),
        num_res_units=config.get("num_res_units", 2),
    ).to(device)
    return model


def build_dataloader(config, split):
    data_dir = config["data_dir"]
    images = sorted(glob(f"{data_dir}/img*.nii.gz"))
    segs = sorted(glob(f"{data_dir}/seg*.nii.gz"))

    n_train = config.get("n_train", 20)
    if split == "train":
        files = [{"img": img, "seg": seg} for img, seg in zip(images[:n_train], segs[:n_train])]
        transforms = Compose([
            LoadImaged(keys=["img", "seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys="img"),
            RandCropByPosNegLabeld(
                keys=["img", "seg"],
                label_key="seg",
                spatial_size=config.get("spatial_size", [96, 96, 96]),
                pos=1,
                neg=1,
                num_samples=config.get("num_samples", 4),
            ),
            RandRotate90d(keys=["img", "seg"], prob=0.5, spatial_axes=[0, 2]),
        ])
        dataset = monai.data.Dataset(data=files, transform=transforms)
        return DataLoader(
            dataset,
            batch_size=config.get("batch_size", 2),
            shuffle=True,
            num_workers=config.get("num_workers", 4),
            collate_fn=list_data_collate,
            pin_memory=torch.cuda.is_available(),
        )
    else:
        files = [{"img": img, "seg": seg} for img, seg in zip(images[n_train:], segs[n_train:])]
        transforms = Compose([
            LoadImaged(keys=["img", "seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys="img"),
        ])
        dataset = monai.data.Dataset(data=files, transform=transforms)
        return DataLoader(
            dataset,
            batch_size=1,
            num_workers=config.get("num_workers", 4),
            collate_fn=list_data_collate,
        )


def train_step(model, batch, optimizer, config):
    device = torch.device(config.get("device", "cuda" if torch.cuda.is_available() else "cpu"))
    loss_function = monai.losses.DiceLoss(sigmoid=True)

    inputs = batch["img"].to(device)
    labels = batch["seg"].to(device)

    optimizer.zero_grad()
    outputs = model(inputs)
    loss = loss_function(outputs, labels)
    loss.backward()
    optimizer.step()

    return loss.item()