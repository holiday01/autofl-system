"""
Auto-generated FL client module.
Original script: monai_3d_segmentation_train.py

Exposes:
  build_model(config)                   -> nn.Module
  build_dataloader(config, split)       -> DataLoader
  train_step(model, batch, opt, config) -> loss tensor
"""
import logging
import os
import sys
import tempfile
from glob import glob

import nibabel as nib
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

import monai
from monai.data import create_test_image_3d, list_data_collate, decollate_batch
from monai.inferers import sliding_window_inference
from monai.metrics import DiceMetric
from monai.transforms import (
    Activations,
    EnsureChannelFirstd,
    AsDiscrete,
    Compose,
    LoadImaged,
    RandCropByPosNegLabeld,
    RandRotate90d,
    ScaleIntensityd,
)
from monai.visualize import plot_2d_or_3d_image

# ── Original source (unchanged) ────────────────────────────────────────
# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


def main(tempdir):
    monai.config.print_config()
    logging.basicConfig(stream=sys.stdout, level=logging.INFO)

    # create a temporary directory and 40 random image, mask pairs
    print(f"generating synthetic data to {tempdir} (this may take a while)")
    for i in range(40):
        im, seg = create_test_image_3d(128, 128, 128, num_seg_classes=1, channel_dim=-1)

        n = nib.Nifti1Image(im, np.eye(4))
        nib.save(n, os.path.join(tempdir, f"img{i:d}.nii.gz"))

        n = nib.Nifti1Image(seg, np.eye(4))
        nib.save(n, os.path.join(tempdir, f"seg{i:d}.nii.gz"))

    images = sorted(glob(os.path.join(tempdir, "img*.nii.gz")))
    segs = sorted(glob(os.path.join(tempdir, "seg*.nii.gz")))
    train_files = [{"img": img, "seg": seg} for img, seg in zip(images[:20], segs[:20])]
    val_files = [{"img": img, "seg": seg} for img, seg in zip(images[-20:], segs[-20:])]

    # define transforms for image and segmentation
    train_transforms = Compose(
        [
            LoadImaged(keys=["img", "seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys="img"),
            RandCropByPosNegLabeld(
                keys=["img", "seg"], label_key="seg", spatial_size=[96, 96, 96], pos=1, neg=1, num_samples=4
            ),
            RandRotate90d(keys=["img", "seg"], prob=0.5, spatial_axes=[0, 2]),
        ]
    )
    val_transforms = Compose(
        [
            LoadImaged(keys=["img", "seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys="img"),
        ]
    )

    # define dataset, data loader
    check_ds = monai.data.Dataset(data=train_files, transform=train_transforms)
    # use batch_size=2 to load images and use RandCropByPosNegLabeld to generate 2 x 4 images for network training
    check_loader = DataLoader(check_ds, batch_size=2, num_workers=4, collate_fn=list_data_collate)
    check_data = monai.utils.misc.first(check_loader)
    print(check_data["img"].shape, check_data["seg"].shape)

    # create a training data loader
    train_ds = monai.data.Dataset(data=train_files, transform=train_transforms)
    # use batch_size=2 to load images and use RandCropByPosNegLabeld to generate 2 x 4 images for network training
    train_loader = DataLoader(
        train_ds,
        batch_size=2,
        shuffle=True,
        num_workers=4,
        collate_fn=list_data_collate,
        pin_memory=torch.cuda.is_available(),
    )
    # create a validation data loader
    val_ds = monai.data.Dataset(data=val_files, transform=val_transforms)
    val_loader = DataLoader(val_ds, batch_size=1, num_workers=4, collate_fn=list_data_collate)
    dice_metric = DiceMetric(include_background=True, reduction="mean", get_not_nans=False)
    post_trans = Compose([Activations(sigmoid=True), AsDiscrete(threshold=0.5)])
    # create UNet, DiceLoss and Adam optimizer
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = monai.networks.nets.UNet(
        spatial_dims=3,
        in_channels=1,
        out_channels=1,
        channels=(16, 32, 64, 128, 256),
        strides=(2, 2, 2, 2),
        num_res_units=2,
    ).to(device)
    loss_function = monai.losses.DiceLoss(sigmoid=True)
    optimizer = torch.optim.Adam(model.parameters(), 1e-3)

    # start a typical PyTorch training
    val_interval = 2
    best_metric = -1
    best_metric_epoch = -1
    epoch_loss_values = list()
    metric_values = list()
    writer = SummaryWriter()
    for epoch in range(5):
        print("-" * 10)
        print(f"epoch {epoch + 1}/{5}")
        model.train()
        epoch_loss = 0
        step = 0
        for batch_data in train_loader:
            step += 1
            inputs, labels = batch_data["img"].to(device), batch_data["seg"].to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = loss_function(outputs, labels)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
            epoch_len = len(train_ds) // train_loader.batch_size
            print(f"{step}/{epoch_len}, train_loss: {loss.item():.4f}")
            writer.add_scalar("train_loss", loss.item(), epoch_len * epoch + step)
        epoch_loss /= step
        epoch_loss_values.append(epoch_loss)
        print(f"epoch {epoch + 1} average loss: {epoch_loss:.4f}")

        if (epoch + 1) % val_interval == 0:
            model.eval()
            with torch.no_grad():
                val_images = None
                val_labels = None
                val_outputs = None
                for val_data in val_loader:
                    val_images, val_labels = val_data["img"].to(device), val_data["seg"].to(device)
                    roi_size = (96, 96, 96)
                    sw_batch_size = 4
                    val_outputs = sliding_window_inference(val_images, roi_size, sw_batch_size, model)
                    val_outputs = [post_trans(i) for i in decollate_batch(val_outputs)]
                    # compute metric for current iteration
                    dice_metric(y_pred=val_outputs, y=val_labels)
                # aggregate the final mean dice result
                metric = dice_metric.aggregate().item()
                # reset the status for next validation round
                dice_metric.reset()

                metric_values.append(metric)
                if metric > best_metric:
                    best_metric = metric
                    best_metric_epoch = epoch + 1
                    torch.save(model.state_dict(), "best_metric_model_segmentation3d_dict.pth")
                    print("saved new best metric model")
                print(
                    "current epoch: {} current mean dice: {:.4f} best mean dice: {:.4f} at epoch {}".format(
                        epoch + 1, metric, best_metric, best_metric_epoch
                    )
                )
                writer.add_scalar("val_mean_dice", metric, epoch + 1)
                # plot the last model output as GIF image in TensorBoard with the corresponding image and label
                plot_2d_or_3d_image(val_images, epoch + 1, writer, index=0, tag="image")
                plot_2d_or_3d_image(val_labels, epoch + 1, writer, index=0, tag="label")
                plot_2d_or_3d_image(val_outputs, epoch + 1, writer, index=0, tag="output")

    print(f"train completed, best_metric: {best_metric:.4f} at epoch: {best_metric_epoch}")
    writer.close()


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tempdir:
        main(tempdir)


# ── FL Interface ────────────────────────────────────────────────────────

def _make_train_transforms(config: dict) -> Compose:
    spatial_size = config.get("spatial_size", [96, 96, 96])
    return Compose([
        LoadImaged(keys=["img", "seg"]),
        EnsureChannelFirstd(keys=["img", "seg"]),
        ScaleIntensityd(keys="img"),
        RandCropByPosNegLabeld(
            keys=["img", "seg"],
            label_key="seg",
            spatial_size=spatial_size,
            pos=1,
            neg=1,
            num_samples=config.get("num_samples", 4),
        ),
        RandRotate90d(keys=["img", "seg"], prob=0.5, spatial_axes=[0, 2]),
    ])


def _make_val_transforms() -> Compose:
    return Compose([
        LoadImaged(keys=["img", "seg"]),
        EnsureChannelFirstd(keys=["img", "seg"]),
        ScaleIntensityd(keys="img"),
    ])


def _collect_file_dicts(data_path: str) -> list[dict]:
    """
    Scan data_path for paired img*.nii.gz / seg*.nii.gz files.
    Falls back to generating synthetic NIfTI pairs in a temp dir if none found.
    """
    images = sorted(glob(os.path.join(data_path, "img*.nii.gz")))
    segs   = sorted(glob(os.path.join(data_path, "seg*.nii.gz")))
    if images and segs:
        n = min(len(images), len(segs))
        return [{"img": img, "seg": seg} for img, seg in zip(images[:n], segs[:n])]

    # synthetic fallback: generate into a persistent subdir so multiple calls share it
    synth_dir = os.path.join(data_path, "_synthetic")
    os.makedirs(synth_dir, exist_ok=True)
    if not glob(os.path.join(synth_dir, "img*.nii.gz")):
        for i in range(40):
            im, seg = create_test_image_3d(128, 128, 128, num_seg_classes=1, channel_dim=-1)
            nib.save(nib.Nifti1Image(im,  np.eye(4)), os.path.join(synth_dir, f"img{i:d}.nii.gz"))
            nib.save(nib.Nifti1Image(seg, np.eye(4)), os.path.join(synth_dir, f"seg{i:d}.nii.gz"))
    images = sorted(glob(os.path.join(synth_dir, "img*.nii.gz")))
    segs   = sorted(glob(os.path.join(synth_dir, "seg*.nii.gz")))
    return [{"img": img, "seg": seg} for img, seg in zip(images, segs)]


def build_model(config: dict) -> torch.nn.Module:
    """Instantiate the MONAI UNet. Override defaults via config['model_kwargs']."""
    defaults = dict(
        spatial_dims=3,
        in_channels=1,
        out_channels=1,
        channels=(16, 32, 64, 128, 256),
        strides=(2, 2, 2, 2),
        num_res_units=2,
    )
    defaults.update(config.get("model_kwargs", {}))
    return monai.networks.nets.UNet(**defaults)


def build_dataloader(config: dict, split: str = "train") -> DataLoader:
    """
    Build a DataLoader for the requested split.
    Expects config to have 'data_path' and optionally 'val_ratio'.
    Client-local batch_size and num_workers are read from config['local'].
    """
    local       = config.get("local", {})
    num_workers = local.get("num_workers", config.get("num_workers", 4))
    pin_memory  = local.get("pin_memory", True)

    data_path = config.get("data_path", ".")
    val_ratio = config.get("val_ratio", 0.5)
    all_files = _collect_file_dicts(data_path)

    n_val   = max(1, int(len(all_files) * val_ratio))
    n_train = len(all_files) - n_val
    rng     = np.random.default_rng(config.get("seed", 42))
    idx     = rng.permutation(len(all_files))
    train_files = [all_files[i] for i in idx[:n_train]]
    val_files   = [all_files[i] for i in idx[n_train:]]

    if split == "train":
        batch_size = local.get("batch_size", config.get("batch_size", 2))
        ds = monai.data.Dataset(data=train_files, transform=_make_train_transforms(config))
        return DataLoader(
            ds,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            collate_fn=list_data_collate,
            pin_memory=pin_memory and torch.cuda.is_available(),
        )
    else:
        ds = monai.data.Dataset(data=val_files, transform=_make_val_transforms())
        return DataLoader(
            ds,
            batch_size=1,
            shuffle=False,
            num_workers=num_workers,
            collate_fn=list_data_collate,
            pin_memory=pin_memory and torch.cuda.is_available(),
        )


def train_step(
    model: torch.nn.Module,
    batch: tuple | list | dict,
    optimizer,
    config: dict,
) -> torch.Tensor:
    """
    Perform one forward (+ optionally backward) step.
    If optimizer is None (preflight forward-only check), skip backward.
    Expects dict batch with 'img' and 'seg' keys (MONAI convention).
    """
    local   = config.get("local", {})
    use_amp = local.get("use_amp", False)
    device  = next(model.parameters()).device

    if isinstance(batch, dict):
        inputs  = batch.get("img", batch.get("image", batch.get("input")))
        targets = batch.get("seg", batch.get("label", batch.get("y")))
        if inputs is None or targets is None:
            raise KeyError(f"Cannot find img/seg keys in batch dict. Keys: {list(batch.keys())}")
        inputs  = inputs.to(device)  if isinstance(inputs,  torch.Tensor) else inputs
        targets = targets.to(device) if isinstance(targets, torch.Tensor) else targets
    elif isinstance(batch, (list, tuple)):
        inputs, targets = batch[0].to(device), batch[1].to(device)
    else:
        raise TypeError(f"Unsupported batch type: {type(batch)}")

    device_type = device.type if hasattr(device, "type") else str(device)
    with torch.autocast(device_type=device_type, enabled=use_amp):
        outputs = model(inputs)
        loss = monai.losses.DiceLoss(sigmoid=True)(outputs, targets)

    if optimizer is not None:
        if use_amp:
            scaler = getattr(train_step, "_scaler", None)
            if scaler is None:
                train_step._scaler = torch.cuda.amp.GradScaler()
                scaler = train_step._scaler
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            optimizer.step()

    return loss.detach()