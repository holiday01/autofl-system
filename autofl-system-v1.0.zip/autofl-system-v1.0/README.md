# AutoFL — System and Benchmark Suite

This Zenodo deposit contains the AutoFL system source code and the
ten-script (plus three non-DL) benchmark suite used in:

> *AutoFL: Skill-Level Prompting Strategies for Automated Federated Learning
> Client Generation*, IEEE Transactions on Neural Networks and Learning
> Systems (under review, 2026).

## Contents

```
autofl-system-v1.0/
├── converter/        # AST rewriter + LLM-based converter (Claude/Gemini/Ollama)
├── preflight/        # 5-stage runtime validator (import / hw / data / forward / backward)
├── fl_runtime/       # Lightweight FLClient / FLServer + FedAvg + non-IID partitioner
├── eval/             # Experiment runners (benchmark, exemplar correction, non-IID)
├── hardware/         # nvidia-smi-based hardware profiler + parameter ladder
├── benchmarks/       # 15 original ML scripts + 39 converted FL clients
│                     #   (PyTorch, TensorFlow, MONAI, Lightning, sklearn, XGBoost)
├── examples/         # Few-shot exemplar (MLP + sample_training_script.py)
├── config/           # Default FL run configuration
├── tests/            # Unit tests
├── cli.py            # Command-line entry: python -m autofl <script>
├── __main__.py
└── __init__.py
```

## Quick start

```bash
# Convert an ML script to an FL client (structured prompting):
export ANTHROPIC_API_KEY=...        # or GOOGLE_API_KEY for Gemini
python -m autofl benchmarks/pytorch/mnist_main.py --strategy structured

# Run the 5-stage preflight validator on a converted file:
python -c "from autofl.preflight.validator import validate; print(validate('benchmarks/pytorch/mnist_main_fl_structured.py'))"

# Run a 3-client FL simulation:
python -m autofl.fl_runtime.run_simulation \
    --client benchmarks/pytorch/mnist_main_fl_structured.py \
    --rounds 5 --num-clients 3
```

## Reproducing paper results

The companion deposit `autofl-results-v*.zip` contains the raw CSV/JSON
outputs of the experiments below. To regenerate them:

| Paper section | Command |
|---------------|---------|
| §5.1–5.4 (40-run primary benchmark, κ analysis, framework breakdown) | `python -m autofl.eval.run_benchmark` |
| §5.5 (FL simulation, PyTorch MNIST + Lightning GAN) | `python -m autofl.fl_runtime.run_simulation` |
| §5.6 (hardware sweep) | `python -m autofl.eval.run_benchmark --hardware-sweep` |
| §5.7 (non-IID convergence, IID + Dirichlet α∈{0.1, 0.5}) | `python -m autofl.fl_runtime.run_simulation_non_iid` |
| §5.8 (non-DL extension, sklearn + XGBoost) | `python -m autofl.eval.non_dl_proxy_validation` |
| §5.9 (exemplar-correction dry-run + real-API) | `python -m autofl.eval.run_exemplar_correction_realapi` |
| §5.10 (cross-provider Gemini + Llama 3) | `python -m autofl.eval.run_benchmark --provider gemini` |

## Dependencies

Python 3.10+; install with:

```
pip install torch torchvision torchaudio
pip install lightning monai tensorflow scikit-learn xgboost
pip install flwr anthropic google-genai
```

## License

See LICENSE in the repository (recommended: MIT or Apache-2.0).

## Citation

```bibtex
@misc{autofl_system_2026,
  title  = {AutoFL: System and Benchmark Suite},
  author = {Chiu, Yen-Jung},
  year   = {2026},
  doi    = {10.5281/zenodo.XXXXXXX},
  note   = {Companion artifact to the AutoFL paper}
}
```
